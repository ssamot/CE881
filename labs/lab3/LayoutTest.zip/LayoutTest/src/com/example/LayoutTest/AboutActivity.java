package com.example.LayoutTest;

import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebView;

public class AboutActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView wb = new WebView(this);
        wb.loadUrl("file:///android_asset/html/About.html");
        setContentView(wb);
        getActionBar().setDisplayHomeAsUpEnabled(true);
    }

        @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        System.out.println("WorkActivity: Menu item: " + item);
        switch (item.getItemId()) {
            case android.R.id.home: {
                // This is called when the Home (Up) button is pressed in the action bar.
                // Create a simple intent that starts the hierarchical parent activity and
                // use NavUtils in the Support Package to ensure proper handling of Up.
                // Intent upIntent = new Intent(this, HomeActivity.class);
                // this.startActivity(upIntent);
                // NavUtils.navigateUpTo(this, upIntent);
                System.out.println("AboutActivity: finishing now");
                finish();
            }
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}

