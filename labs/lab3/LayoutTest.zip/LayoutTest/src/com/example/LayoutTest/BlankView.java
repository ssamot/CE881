package com.example.LayoutTest;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class BlankView extends View {
    public BlankView(Context context) {
        super(context);
        System.out.println("BlankView: made one!");
    }

    public BlankView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public BlankView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
//        Paint paint = new Paint();
//        paint.setStyle(Paint.Style.FILL);
//        paint.setAntiAlias(true);
//        // paint.setColor(R.color.powder_blue);
//        paint.setColor(Color.RED);
//        // System.out.println("BlankView: " + getWidth() +  " : " + getHeight() + " : " + R.color.powder_blue);
//        canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
//        paint.setStyle(Paint.Style.STROKE);
//        paint.setColor(Color.GREEN);
//        paint.setStrokeWidth(10);
//        canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
    }
}
