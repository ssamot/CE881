package com.example.LayoutTest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buttons);
        new MyTask().execute(null, null, null);


        try {
            Thread thread = new Thread() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(2000);
                        handleButtonOne(null);

                    } catch (Exception e) {
                        System.out.println("MyThreadTest Inner Exception: " + e);
                    }
                }
            };
            thread.start();
        } catch (Exception e) {
            System.out.println("MyThreadTest Outer Exception: " + e);
            e.printStackTrace();
        }

    }

    public void handleButtonOne(View view) {
        setContentView(R.layout.linear);
    }

    public void handleButtonTwo(View view) {
        setContentView(R.layout.buttons);
    }

    private class MyTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Thread.sleep(2000);
            } catch ( Exception e) {}
            return null;
        }

        protected void onPostExecute(Void result) {
            // new Toast(this)
            handleButtonOne(null);
        }
    }

    static String aboutItem = "About";

    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(aboutItem);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle().equals(aboutItem)) {
            Intent intent =
                    new Intent(this, AboutActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    AlertDialog alertDialog;
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0)
        {

            alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("I see you're trying to leave.");
            alertDialog.setMessage("Are you sure?");

            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE,
                    "Yes", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    finish();
                }
            });

            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE,
                    "No", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    // do nothing dialog will dismiss
                }
            });

            alertDialog.show();
            return true; //meaning you've dealt with the keyevent
        }
        return super.onKeyDown(keyCode, event);
    }

}

