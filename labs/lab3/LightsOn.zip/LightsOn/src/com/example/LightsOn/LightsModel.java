package com.example.LightsOn;

import android.content.Context;
import android.view.View;
import android.widget.Button;

import java.io.Serializable;
import java.util.Arrays;

public class LightsModel implements Serializable {

    int[][] grid;
    boolean notStrict = true;
    int n;

    public LightsModel(int n) {
        this.n = n;
        grid = new int[n][n];
    }

    public boolean isSwitchOn(int i, int j) {
        return grid[i][j] == 1;
    }

    // method to flip the state of all the lights
    // in line with cell i,j
    public void flipLines(int i, int j) {


        for (int k = 0; k < n; k++) {
            grid[i][k] = 1 - grid[i][k];
            grid[k][j] = 1 - grid[k][j];
        }
        // the switch i,j has been flipped twice
        // so flip it again to actually change its state
        grid[i][j] = 1 - grid[i][j];
    }

    public boolean isSolved() {
        int tot = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                tot += grid[i][j];
            }
        }
        return tot >= n * n - 1;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append(Arrays.toString(grid[i]) + "\n");
        }
        return sb.toString();
    }

    public void tryFlip(int i, int j) {
        try {
            if (isSwitchOn(i, j) || notStrict) {
                flipLines(i, j);
            }
        } catch (Exception e) {
            // this catch block is to handle ArrayOutOfBounds exceptions
        }
    }

    public void reset() {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                grid[i][j] = 1;
            }
        }
    }

    public int getScore() {
        int tot = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                tot += grid[i][j];
            }
        }
        return tot;
    }

    public void resetModel(View view) {
        reset();
    }
}
