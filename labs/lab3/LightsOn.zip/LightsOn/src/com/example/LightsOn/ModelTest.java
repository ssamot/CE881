package com.example.LightsOn;

public class ModelTest {
    public static void main(String[] args) {
        // use default version of model
        LightsModel model = new LightsModel(5);
        System.out.println(model);
        model.flipLines(2, 2);
        System.out.println(model);
        model.flipLines(1, 2);
        System.out.println(model);
        model.flipLines(1, 1);
        System.out.println(model);
    }
}




