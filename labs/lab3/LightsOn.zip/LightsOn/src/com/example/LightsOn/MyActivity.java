package com.example.LightsOn;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class MyActivity extends Activity {

    // declare size of nxn puzzle grid
    static int nDefault = 7;
    LightsModel model;
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // model = new LightsModel(n);
        // setContentView(new LightsView(this, new LightsModel(n)));
        setContentView(R.layout.main);
    }

    public void resetModel(View view) {
        LightsView lightsView =
                (LightsView) findViewById(R.id.lightsView);
        // lightsView.model.reset();
        model.reset();
        lightsView.postInvalidate();
    }

    public LightsModel getModel() {
        if (model == null) {
            model = new LightsModel(nDefault);
        }
        return model;
    }

    public void onStop() {
        super.onStop();
    }

    static String modelKey = "Model";

    public void onSaveInstanceState(Bundle savedInstanceState) {
        // Save the user's current game state
        savedInstanceState.putSerializable(modelKey, getModel());

        // Always call the superclass so it can
        // save the view hierarchy state
        super.onSaveInstanceState(savedInstanceState);
    }

    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        model = (LightsModel)
                savedInstanceState.getSerializable(modelKey);
    }
}



