package com.example.MenusAndDialogs;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.NumberPicker;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */

    NumberPicker numberPicker;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        numberPicker = (NumberPicker) findViewById(R.id.numberPicker);
        numberPicker.setMaxValue(10);
        numberPicker.setMinValue(5);
        numberPicker.setValue(7);
        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int i2) {

                System.out.println("NumberPicker: " + numberPicker);
                System.out.println("NumberPicker: " + i + " : " + i2);

            }
        });
        // numberPicker.
    }

//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.menu1, menu);
//        return true;
//    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle().equals(mapItem)) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:" + 42.516845 + "," + -70.898503));
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    static String mapItem = "Map";

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem test = menu.add("Test");
        test.setIcon(R.drawable.ic_launcher);
        // test.setActionView(new MyView(this, Color.BLUE));
        test.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

        MenuItem best = menu.add(mapItem);
        // best.setActionView(new MyView(this, Color.RED));
        best.setIcon(new MyDraw("?", Color.WHITE, Color.RED));
        // best.setIcon(android.R.drawable.ic_menu_agenda);
        // best.setIcon(android.R.drawable.ic_menu_upload_you_tube);
        best.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);


        return true;
    }



    class MyView extends View {

        public void onDraw(Canvas canvas) {
            Paint paint = new Paint();
            paint.setColor(col);
            paint.setStyle(Paint.Style.FILL);
            // canvas.getClipBounds()
            canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
        }

        int col;

        public MyView(Context context, int col) {
            super(context);
            this.col = col;
        }

        public MyView(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        public MyView(Context context, AttributeSet attrs, int defStyle) {
            super(context, attrs, defStyle);
        }
    }

    class MyDraw extends Drawable {

        String tag = "MyDraw: ";
        String text;
        int fg;
        int bg;

        MyDraw(String text, int fg, int bg) {
            this.text = text;
            this.fg = fg;
            this.bg = bg;
        }


        @Override
        public void draw(Canvas canvas) {
//            System.out.println(tag + " draw: " + getMinimumWidth() + " : " + getIntrinsicHeight());
            System.out.println(tag + " draw: " + canvas.getClipBounds());
            Paint paint = new Paint();
            paint.setColor(bg);
            paint.setStyle(Paint.Style.FILL);
            paint.setAntiAlias(true);
            Rect clip = canvas.getClipBounds();
            int size = Math.min(canvas.getWidth(), canvas.getHeight());
            int inset = size / 20;

            RectF r1 = new RectF(clip.left + inset, clip.top + inset,
                    clip.right - inset, clip.bottom - inset);
            canvas.drawRoundRect(r1, 10, 10, paint);

            paint.setColor(fg);
            paint.setTextSize(0.8f * size);
            paint.setTypeface(Typeface.DEFAULT_BOLD);

            // canvas.translate(size / 2, size / 2);
            Rect bounds = new Rect();
            paint.getTextBounds(text, 0, text.length(), bounds);

            float lx = -bounds.centerX() + clip.centerX();
            float ly = -bounds.centerY() + +clip.centerY();
            canvas.drawText(text, lx, ly, paint);

        }

        @Override
        public void setAlpha(int i) {
            System.out.println(tag + " setAlpha");
            //To change body of implemented methods use File | Settings | File Templates.
        }

        @Override
        public void setColorFilter(ColorFilter colorFilter) {
            System.out.println(tag + " setColorFilter");
            //To change body of implemented methods use File | Settings | File Templates.
        }

        @Override
        public int getOpacity() {
            System.out.println(tag + " getOpacity");
            return 0xFFFFFFFF;
        }
    }


}
