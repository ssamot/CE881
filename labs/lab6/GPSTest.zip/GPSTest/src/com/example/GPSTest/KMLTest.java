package com.example.GPSTest;

import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

/**
 * Program to read a set of GPS coordinates.
 * This test is to be run from the command line
 * as a normal Java program
 */
public class KMLTest {

    static String testFileName = "assets/SampleRoute.txt";
    static String kmlOutFile = "assets/SampleRoute.kml";

    static String kmlRoot = "kml";
    static String docRoot = "Document";
    static String placeMark = "Placemark";
    static String name = "name";
    static String description = "description";
    static String point = "Point";
    static String coordinates = "coordinates";
    static String nameSpace = "http://www.opengis.net/kml/2.2";

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(new File(testFileName));
        // note use of namespace URI
        Element root = new Element(kmlRoot, nameSpace);

        Element doc = new Element(docRoot);
        root.addContent(doc);

        int placeNumber = 1;
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            doc.addContent(getPlace(line, placeNumber));
            placeNumber++;
        }

        XMLOutputter out = new XMLOutputter();
        out.setFormat(Format.getPrettyFormat());
        FileWriter outFile = new FileWriter(kmlOutFile);
        out.output(root, outFile);

    }

    public static Element getPlace(String line, int label) {
        Scanner scanner = new Scanner(line);
        double lat = scanner.nextDouble();
        double lon = scanner.nextDouble();
        // zero is for altitude: this is interpreted
        // as height above ground level
        String coords = String.format("%.6f,%.6f,0", lon, lat);
        Element place = new Element(placeMark);
        Element nm = new Element(name);
        nm.addContent("p " + label);
        Element p = new Element(point);
        Element cs = new Element(coordinates);
        cs.addContent(coords);
        place.addContent(nm);
        place.addContent(p);
        p.addContent(cs);
        return place;
    }

}
