package com.example.GPSTest;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import com.example.utilities.StatSummary;

public class MapView extends View implements View.OnTouchListener {
    // GestureDetector.OnGestureListener {

    static Paint paint = new Paint();

    static {
        paint.setColor(Color.CYAN);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
    }


    private ScaleGestureDetector scaleDetector;
    private float scaleFactor = 1.f;

    MapViewActivity controller;

    static double eps = 1e-10;

    public void onDraw(Canvas canvas) {
        try {
            MyPath path = controller.getPath();

            // now have some interesting calculations to do
            // want to centre this path on the other one

            StatSummary ssx = path.ssx;
            StatSummary ssy = path.ssy;

            // difference between min and max for each
            double xRange = ssx.max() - ssx.min();
            double yRange = ssy.max() - ssy.min();

            double xDegreesPerPixel = xRange / getWidth();
            double yDegreesPerPixel = yRange / getHeight();

            // keep the aspect ratio so choose the max
            double degreesPerPixel = Math.max(xDegreesPerPixel, yDegreesPerPixel);

            float pixelsPerDegree = (float) (1.0 / (degreesPerPixel + eps));

            // centre points in degrees
            float cLon = (float) (ssx.min() + (ssx.max() - ssx.min()) / 2);
            float cLat = (float) (ssy.min() + (ssy.max() - ssy.min()) / 2);

            // create the canvas path to draw
            Path cPath = new Path();
            // move to the first point on the route
            MyPoint first = path.getPath().get(0);
            float sx = (first.x - cLon) * pixelsPerDegree;
            float sy = (first.y - cLat) * pixelsPerDegree;
            cPath.moveTo(sx, sy);
            for (MyPoint p : path.getPath()) {
                float x = (p.x - cLon) * pixelsPerDegree;
                float y = (p.y - cLat) * pixelsPerDegree;
                cPath.lineTo(x, y);
            }
            // cPath.close();
            canvas.translate(getWidth() / 2, getHeight() / 2);
            // note the negative: lat is pos up, Canvas is pos down
            canvas.scale(scaleFactor, -scaleFactor);
            canvas.drawPath(cPath, paint);
            //
        } catch (Exception e) {
            System.out.println("MapView: " + e);
            e.printStackTrace();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        boolean retVal = scaleDetector.onTouchEvent(event);
        return retVal || super.onTouchEvent(event);
    }


    private void init(Context context) {
        try {
            scaleDetector = new ScaleGestureDetector(
                    context, new ScaleListener());
            setOnTouchListener(this);
            // this.setg
            controller = (MapViewActivity) context;
        } catch (Exception e) {
            System.out.println("MapView Constructor: " + e);
            e.printStackTrace();
        }
    }

    private class ScaleListener
            extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            scaleFactor *= detector.getScaleFactor();
            // System.out.println("MapView: rawScale" + scaleFactor);
            // Don't let the object get too small or too large.
            scaleFactor = Math.max(0.1f, Math.min(scaleFactor, 5.0f));

            invalidate();
            return true;
        }
    }

    public MapView(Context context) {
        super(context);
        init(context);
    }

    public MapView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MapView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }


    // handle these for other gestures

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }
//
//    @Override
//    public boolean onDown(MotionEvent motionEvent) {
//        return false;  //To change body of implemented methods use File | Settings | File Templates.
//    }
//
//    @Override
//    public void onShowPress(MotionEvent motionEvent) {
//        //To change body of implemented methods use File | Settings | File Templates.
//    }
//
//    @Override
//    public boolean onSingleTapUp(MotionEvent motionEvent) {
//        return false;  //To change body of implemented methods use File | Settings | File Templates.
//    }
//
//    @Override
//    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float v, float v2) {
//        return false;  //To change body of implemented methods use File | Settings | File Templates.
//    }
//
//    @Override
//    public void onLongPress(MotionEvent motionEvent) {
//        //To change body of implemented methods use File | Settings | File Templates.
//    }
//
//    @Override
//    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float v, float v2) {
//        return false;  //To change body of implemented methods use File | Settings | File Templates.
//    }
}
