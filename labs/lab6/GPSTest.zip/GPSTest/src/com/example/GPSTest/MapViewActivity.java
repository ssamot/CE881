package com.example.GPSTest;

import android.app.Activity;
import android.os.Bundle;

public class MapViewActivity extends Activity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        System.out.println("MapViewActivity: onCreate()");
        setContentView(new MapView(this));
    }

    static MyPath path;

    public MyPath getPath() {
        if (path == null) {
            path = PathTest.getDefaultAssetPath(this.getAssets());
        }
        return path;
    }



}
