package com.example.GPSTest;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */

    static String tag = "GPSTest: ";
    TextView view;
    int nUpdates = 0;

    static String routeDirName = "routeTest";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        view = new TextView(this);
        view.setText("Waiting for Location");
        view.setTextSize(35);
        setContentView(view);

        // Acquire a reference to the system Location Manager
        LocationManager locationManager = (LocationManager)
                this.getSystemService(Context.LOCATION_SERVICE);

        // Define a listener that responds to location updates
        LocationListener locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                // Called when a new location is found by the
                // network location provider.
                makeUseOfNewLocation(location);
            }

            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            public void onProviderEnabled(String provider) {
            }

            public void onProviderDisabled(String provider) {
            }
        };

        // Register the listener with the
        // Location Manager to receive location updates
        locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 0, 0, locationListener);

    }

    static String mapItem = "View Map";

    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(mapItem);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        System.out.println("MapView MyActivity: menuItem: " + item.getTitle());
        if (item.getTitle().equals(mapItem)) {
            Intent intent =
                    new Intent(this, MapViewActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public File getRouteStorageDir(String routeDirName) {
        // Get the directory for the user's public pictures directory.
        // File file = new File(Environment.getDataDirectory(), routeDirName);
        File file = new File(Environment.getExternalStorageDirectory(), routeDirName);
        if (!file.mkdirs()) {
            Log.e(tag, "Directory not created. failed");
        } else {
            Log.e(tag, "Directory created");
            System.out.println(tag + " Directory: " + file.toString());
        }
        return file;
    }

    /* Checks if external storage is available for read and write */
    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

    public void logLocation(String line) {
        try {
            writer.println(line);
        } catch (Exception e) {
            System.out.println(tag + e);
            e.printStackTrace();
        }
    }

    PrintWriter writer;

    long startTime;
    public void onStart() {
        super.onStart();
        startTime = System.currentTimeMillis();
        System.out.println(tag + isExternalStorageWritable());
        try {
            File dir = getRouteStorageDir(routeDirName);
            String fileName = "route-" +
                    (System.currentTimeMillis() / 1000) + ".txt";
            File outFile = new File(dir, fileName);
            System.out.println(tag + "Directory: outFile " +
                    outFile.getAbsolutePath());
            writer = new PrintWriter(new FileWriter(outFile));
            System.out.println(tag + "Directory root: " +
                    dir.getAbsolutePath());
        } catch (Exception e) {
            System.out.println(tag + "Directory: " + e);
            e.printStackTrace();
        }
    }

    public void onStop() {
        super.onStop();
        try {
            writer.close();
        } catch (Exception e) {
            System.out.println(tag + e);
            e.printStackTrace();
        }
    }


    static Gson gson = new Gson();

    public void makeUseOfNewLocation(Location location) {
        try {

            long t = (System.currentTimeMillis() - startTime) / 1000;
            nUpdates++;
            String str = String.format("%.8f\n %.8f\n %.5f\n %.2f\n %d\n %d\n %s\n %s",
                    location.getLatitude(),
                    location.getLongitude(),
                    location.getAltitude(),
                    location.getAccuracy(),
                    nUpdates,
                    t,
                    writer,
                    isExternalStorageWritable()
            );

            String filestr = String.format("%.8f\t %.8f\t %.5f\t %.2f\t %d \t %d",
                    location.getLatitude(),
                    location.getLongitude(),
                    location.getAltitude(),
                    location.getAccuracy(),
                    nUpdates,
                    t
            );

            System.out.println(gson.toJson(location));
            System.out.println();

            view.setText(str);
            logLocation(filestr);
        } catch (Exception e) {
            System.out.println("GPSTest: " + e);
            e.printStackTrace();
        }
    }
}
