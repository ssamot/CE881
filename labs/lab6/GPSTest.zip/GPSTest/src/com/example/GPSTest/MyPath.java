package com.example.GPSTest;

import com.example.utilities.StatSummary;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MyPath {
    List<MyPoint> path;
    StatSummary ssx, ssy;

    public MyPath() {
        path = new ArrayList<MyPoint>();
        ssx = new StatSummary();
        ssy = new StatSummary();
    }

    static int latIndex = 0;
    static int lonIndex = 1;
    static int accIndex = 3;

    public void addPoint(String str) {
        try {
            String[] values = str.split(" ");
            float lat = Float.valueOf(values[latIndex]);
            float lon = Float.valueOf(values[lonIndex]);
            ssx.add(lon);
            ssy.add(lat);
            float acc = Float.valueOf(values[accIndex]);
            MyPoint p = new MyPoint(lon, lat, acc);
            path.add(p);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addPointOld(String str) {
        // Scanner is so slow!
        try {
            Scanner scanner = new Scanner(str);
            float lat = (float) scanner.nextDouble();
            float lon = (float) scanner.nextDouble();
            ssx.add(lon);
            ssy.add(lat);
            // discard altitude
            scanner.nextDouble();
            float acc = (float) scanner.nextDouble();
            MyPoint p = new MyPoint(lon, lat, acc);
            path.add(p);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<MyPoint> getPath() {
        return path;
    }
}


