package com.example.GPSTest;

public class MyPoint {
    float x, y, acc;

    public MyPoint(float x, float y, float acc) {
        this.x = x;
        this.y = y;
        this.acc = acc;
    }

    public String toString() {
        return String.format("[%.7f, %.7f, %.2f]", x, y, acc);
    }
}


