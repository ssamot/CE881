package com.example.GPSTest;

import android.content.res.AssetManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class PathTest {

    public static void main(String[] args) {
        System.out.println(getDefaultPath().getPath());
    }

    static String testFileName = "assets/SampleRoute.txt";

    static String assetsFileName = "SampleRoute.txt";

    public static MyPath getDefaultPath() {
        return getDefaultPath(testFileName);
    }

//    public MyPath getDefaultAssetPath() {
//        return getDefaultAssetPath();
//    }
//
    public static MyPath getDefaultAssetPath(AssetManager assets) {
        MyPath path = new MyPath();
        try {
            System.out.println("Map: Reading path");
            long t = System.currentTimeMillis();
            InputStream in = assets.open(assetsFileName, AssetManager.ACCESS_BUFFER);
            BufferedReader br = new BufferedReader(new InputStreamReader(in), 100000);
            System.out.println("Map: Buffered: " + (System.currentTimeMillis() - t));
            String line;
            while ((line = br.readLine()) != null) {
                path.addPoint(line);
            }
            System.out.println("Map: Read Path: " + (System.currentTimeMillis() - t));
        } catch (Exception e) {

        }
        return path;
    }

    public static MyPath getDefaultPath(String fileName) {
        MyPath path = new MyPath();
        try {
            Scanner scanner = new Scanner(new File(fileName));
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                path.addPoint(line);
            }
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        }
        return path;
    }


}
