package com.example.NetworkSimpleTest;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class NetActivity extends Activity {

    WebView webView;
    static String tag = "NetTest: ";

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.loadData("<html><body>Use menu to load data</body></html>",
                "text/html", null);
        setContentView(webView);
    }

    static String load = "Load", drop = "Drop", share = "Share";

    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(load);
        menu.add(drop);
        menu.add(share);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle().equals(load)) {
            try {
                // what are the units of a Toast's duration?
                Toast.makeText(this, "Loading", Toast.LENGTH_LONG).show();
                System.out.println(tag + "Toast Length: " + Toast.LENGTH_LONG);
                loadPage();
            } catch (Exception e) {
                System.out.println(tag + e.toString());
                e.printStackTrace();
            }
        }
        if (item.getTitle().equals(drop)) {
            webView.loadData("<html><body>Dropped: Use menu to load data</body></html>",
                    "text/html", null);
        }
        if (item.getTitle().equals(share)) {
            sharingTest("New Griddle high score: 144! https://play.google.com/store/apps/details?id=com.lucapps.state&hl=en_GB");
        }
        return super.onOptionsItemSelected(item);
    }

    public void loadPage() {
        new WebTask().execute();
    }

    public void sharingTest(String message) {
        Log.i(tag, "Trying to share " + message);
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, message);
        sendIntent.setType("text/plain");
        startActivity(Intent.createChooser(
                sendIntent, "Share using?"));
    }


    private class WebTask extends AsyncTask<Void, Void, Void> {
        long t = System.currentTimeMillis();
        String htmlString = "oops";

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                // note: for HTML we could let a WebView do
                // all the work
                // or for JSON we could use the GSON reader do the work
                System.out.println("NetTest: Doing in background ...");

                // write rest of method here

            } catch (Exception e) {
                htmlString = e.toString();
            }
            return null;
        }

        protected void onPostExecute(Void result) {
            System.out.println("onPostExecute()");
            webView.loadData(htmlString, "text/html", null);
        }
    }

    // Given a string representation of a URL, sets up a connection and gets
    // an input stream.  Method is from developer.android.com NetworkUsage sample
    private InputStream downloadUrl(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setReadTimeout(10000 /* milliseconds */);
        conn.setConnectTimeout(15000 /* milliseconds */);
        conn.setRequestMethod("GET");
        conn.setDoInput(true);
        // Starts the query
        conn.connect();
        InputStream stream = conn.getInputStream();
        return stream;
    }

    // this method shows how to read bytes from a stream until EoS
    private void readBytes(InputStream is) throws IOException {
        int x;
        while (((x = is.read())) != -1) {
            System.out.println(x);
        }
        is.close();
    }
}

