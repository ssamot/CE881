package com.example.NetworkSimpleTest;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public class NetUtil {
    public static void main(String[] args) {
        String url = "http://algoval.essex.ac.uk";
        // String url = "http://localhost:8080";
        System.out.println(loadString(url));
    }

    public static String loadString(String url) {
        try {
            URL myURL = new URL(url);
            URLConnection myURLConnection = myURL.openConnection();
            InputStream is = myURLConnection.getInputStream();
            BufferedInputStream bis = new BufferedInputStream(is, 20000);
            int i;
            StringBuffer sb = new StringBuffer();
            while ((i = bis.read()) != -1) {
                sb.append(i);
            }
            bis.close();
            return sb.toString();
        } catch (Exception e) {
            return e.toString();
        }
    }
}


