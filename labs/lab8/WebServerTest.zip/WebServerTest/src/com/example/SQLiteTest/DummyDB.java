package com.example.SQLiteTest;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class DummyDB implements ScoreDB {
    public TreeSet<Score> scores;

    public DummyDB() {
        scores = new TreeSet<Score>();
    }

    @Override
    public Score highScore() {
        return scores.first();
    }

    @Override
    public ArrayList<Score> topN(int n) {
        ArrayList<Score> list = new ArrayList<Score>();
        for (Score s : scores) {
            list.add(s);
            if (list.size() == n) break;
        }
        return list;
    }

    @Override
    public void addScore(Score score) {
        // prevent a DoS by limiting the number of scores stored
        if (scores.size() > 20) createTable();
        scores.add(score);
    }

    @Override
    public void dropTable() {
        scores = null;
    }

    @Override
    public void createTable() {
        scores = new TreeSet<Score>();
    }
}
