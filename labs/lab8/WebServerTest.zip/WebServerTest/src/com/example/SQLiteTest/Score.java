package com.example.SQLiteTest;

public class Score implements Comparable<Score> {
    public long timeStamp;
    public String person;
    public Integer score;

    public Score(long timeStamp, String person, int score) {
        this.timeStamp = timeStamp;
        this.person = person;
        this.score = score;
    }

    public Score(String person, int score) {
        this(System.currentTimeMillis(), person, score);
    }

    @Override
    public int compareTo(Score other) {
        return -score.compareTo(other.score);
    }
}
