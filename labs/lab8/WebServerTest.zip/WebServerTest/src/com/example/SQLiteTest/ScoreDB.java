package com.example.SQLiteTest;

import java.util.ArrayList;
import java.util.List;

public interface ScoreDB {
    Score highScore();
    ArrayList<Score> topN(int n);
    void addScore(Score score);
    void dropTable();
    void createTable();
}

