package com.example.SQLiteTest;

import java.util.ArrayList;

public class ScoreList {
    ArrayList<Score> scoreList;

    public ScoreList(ArrayList<Score> scoreList) {
        this.scoreList = scoreList;
    }
}
