package com.example.SQLiteTest;

public class Singleton {
    public static DummyDB dummy = new DummyDB();
    static {
        dummy.addScore(new Score("Simon", 1000));
        dummy.addScore(new Score("John", 2000));
        dummy.addScore(new Score("Mary", 3000));
    }
}
